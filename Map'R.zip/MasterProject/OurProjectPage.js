import React from "react";
import "./Navbar.css";
import "./HomePage.css";
import logo from "./images/logo1.png";

const OurProjectPage = ({ onStart, onAboutUsClick, onOurProjectClick,onReturnToHome,onVoirLaCarteClick }) => {
  return (
    <div>
      <div className="navbar">
        
      <img src={logo} alt="Logo" className="logo" />
        <button className="nav-button">Accueil</button>
        <button className="nav-button" onClick={onOurProjectClick}>
          Notre projet
        </button> 
        
        <button className="nav-button" onClick={onVoirLaCarteClick}>
          Voir la Carte
        </button> 
        <button className="nav-button" onClick={onAboutUsClick}>
          About Us
        </button>  
      </div>
      
      <div className="content">
      <h1>Notre Projet</h1>
      <p>Nous sommes un groupe de 8 étudiants d'Efrei Paris. Nous avons décidé de travailler sur la qualité de l'air du métro parisien...<br></br>
      </p>
      <p> <img src={logo} alt="Logo" className="logoOurProject" /></p>
      <button className="return-button" onClick={onReturnToHome}>
        Retour
      </button>
    </div>
    </div>


  );
};




export default OurProjectPage;
