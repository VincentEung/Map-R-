import React from "react";
import "./HomePage.css";
import "./Info.css";
import logoMAPR from "./images/MAPR.png"
import logoPH from"./images/PMCALCUL.png"

export default function Info ({ handleHp, onStart, infoClick, handleGraph, handlePredictions}) {
    
    const handleNavigateToNewPage = () => {
        handleGraph();  // Appeler la fonction handleGraph lors du clic sur le bouton
      };
    
    const handleNavigateToPredictions = () => {
    handlePredictions();  // Appeler la fonction handleGraph lors du clic sur le bouton
    };

    return (
        <div className="main">
        {/*----navigation bar----*/}
            <nav className="navbar">
                <a href="HomePage.js" className="hp">MAP'R</a>
                <div className="bars">
                <div className="barinfo" onClick={handleHp}> Accueil</div>
                <div className="barinfo" onClick={onStart}> Visualiser la carte </div>
                <div className="barinfo" onClick={handleNavigateToNewPage}> Graphiques </div>
                <div className="barinfo" onClick={handleNavigateToPredictions}> Prédictions </div>
                <div className="barinfo" onClick={infoClick}> Plus d'informations </div>
                </div>
            </nav>

            {/* ---- Infos ---- */}
            <div className="boxes">
                {/* ... Contexte etc. ... */}

                {/* ---- Plus d'info ---- */}
                <div className="info-section">
                    <h2>Plus d'Info</h2>
                    <div className="info-content">
                        <img src={logoMAPR} alt="Logo" className="info-logo" />
                        <p>Bienvenue dans notre application dédiée à la visualisation des mesures de particules fines PM2,5 et PM10, ainsi que de la température et de l'humidité au sein du métro. Cet outil a été conçu pour offrir une représentation claire de la qualité de l'air que les voyageurs respirent quotidiennement. Nous tenons à exprimer notre profonde gratitude à Yassine Mhamdi, Vincent Eung, Julien Mirgaine, Emile BENVENISTE, Martin AMIREILLE, Laura BENAVENUTO, Romane Simmonet, Pierre BERGEROT, Rémy RICOCHIN et Yannick Pierre-Marie pour leur précieuse collaboration qui a rendu ce projet possible.</p>
                    </div>
                </div>

                {/* ---- Comment ça marche ---- */}
                <div className="how-it-works-section">
                    <h2>Comment ça marche</h2>
                    <div className="how-it-works-content">
                        <p>La précision de la surveillance de la qualité de l'air repose sur le calcul méticuleux des concentrations de particules fines et d'autres polluants. Ces taux sont mesurés en utilisant des capteurs spécialisés qui enregistrent continuellement les niveaux de PM2.5, PM10, ainsi que d'autres indicateurs comme le NO2, O3 et SO2. Les mesures des PM sont souvent exprimées en microgrammes par mètre cube d'air et sont calculées sur une moyenne journalière pour fournir un aperçu fiable de l'exposition des individus à la pollution. De plus, des observations phénologiques et des indices cliniques et météorologiques sont pris en compte pour affiner ces mesures, permettant ainsi d'offrir une image complète des conditions environnementales.</p>
                        {/* Insérez vos images ici */}
                        <img src={logoPH} alt="Logo" className="info-logo" />
                        {/* Autres images et textes si nécessaire */}
                        <p>Ces données essentielles sont ensuite intégrées dans une carte interactive, rendant l'information accessible et compréhensible pour le public. En plus de présenter les niveaux actuels de pollution, la carte est enrichie par des prédictions établies sur la base de ces mesures et d'autres facteurs environnementaux tels que la température et l'humidité. Cette approche multidimensionnelle permet non seulement de visualiser l'état actuel de la qualité de l'air dans le métro, mais aussi d'anticiper les conditions futures, offrant ainsi un outil précieux pour la sensibilisation et la planification urbaine. </p>
                    </div>
                </div>

                {/* ---- Actualité ---- */}
                <div className="news-section">
                    <h2>Actualité</h2>
                    <div className="news-content">
                        {/* Articles - Exemple d'article */}
                        <div className="news-article">
                            <h3>Pollution de l’air dans le métro : trois stations de l’Est parisien dans le rougee</h3>
                            <p>Selon une étude d’Ile-de-France Mobilités, menée avec l’appui d’Airparif, trois stations affichent une concentration de particules fines PM10 dépassant le seuil maximal recommandé par l’Anses : Belleville, Jaurès et Oberkampf.</p>
                            <a href="https://www.lemonde.fr/planete/article/2024/01/22/pollution-de-l-air-dans-le-metro-trois-stations-de-l-est-parisien-dans-le-rouge_6212236_3244.html" target="_blank" rel="noopener noreferrer">Lire plus</a>
                        </div>
                        <div className="news-article">
                            <h3>Pollution dans le métro parisien : d’où viennent les particules fines qui y pullulent ?</h3>
                            <p>Île-de-France Mobilités (IDFM) a publié, lundi 22 janvier, une étude de la pollution de l’air de 44 stations du métro et du RER parisiens. Elle révèle des niveaux importants dans certaines stations. IDFM revendique des solutions à l’étude ou en cours d’installation pour lutter contre le phénomène.</p>
                            <a href="https://www.la-croix.com/sante/pollution-dans-le-metro-parisien-d-ou-viennent-les-particules-fines-qui-y-pullulent-20240122" target="_blank" rel="noopener noreferrer">Lire plus</a>
                        </div>
                        <div className="news-article">
                            <h3>Ventilation, freinage, filtration… Quelles solutions pour réduire la pollution dans le métro ?</h3>
                            <p>Île-de-France Mobilités et Airparif publient ce lundi une première carte présentant le niveau de présence de particules fines dans 44 stations et gares RER. Elle va permettre de lancer rapidement des actions correctives.</p>
                            <a href="https://www.leparisien.fr/info-paris-ile-de-france-oise/transports/ventilation-freinage-filtration-quelles-solutions-pour-reduire-la-pollution-dans-le-metro-22-01-2024-RXKK7LMRNNBCFHKYYC6M7ZPM2Y.php" target="_blank" rel="noopener noreferrer">Lire plus</a>
                        </div>
                        {/* Autres articles */}
                    </div>
                </div>
            </div>
        </div>
    )
}
