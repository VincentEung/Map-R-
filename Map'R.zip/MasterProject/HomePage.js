import React from "react";
import "./HomePage.css";

export default function HomePage({ handleHp, onStart, infoClick, handleNoMap, handleGraph, handlePredictions}) {
  
  const handleStart = () => {
    onStart();
  };

  const handleNavigateToNewPage = () => {
    handleGraph();  // Appeler la fonction handleGraph lors du clic sur le bouton
  };

  const handleNavigateToPredictions = () => {
    handlePredictions();  // Assurez-vous que 'PredictionsPage' est le nom correct de votre écran de prédictions
  };

  return (
    <div className="main">
      {/*----navigation bar----*/}
      <nav className="navbar">
        <a href="HomePage.js" className="hp">MAP'R</a>
        <div className="bars">
          <div className="barinfo" onClick={handleHp}> Accueil</div>
          <div className="barinfo" onClick={onStart}> Visualiser la carte </div>
          <div className="barinfo" onClick={handleNavigateToNewPage}> Graphiques </div>
          <div className="barinfo" onClick={handleNavigateToPredictions}> Prédictions </div>
          <div className="barinfo" onClick={infoClick}> Plus d'informations </div>
        </div>
      </nav>

        {/* ----homepage---- */}  
        <div className="slider">
          <div className="slide">
            <img
              src="https://www.villaschweppes.com/app/uploads/2016/01/109616-la-carte-du-metro-creee-par-buzzfeed-pou-orig-2.png"
              alt="Background"
            />
            <div className="info">
              <h1>MAP'R</h1>
              <p>Une carte interactive permettant aux utilisateurs
                de visualiser le taux de pollution dans toutes les 
                stations du réseau de chemin de fer métropolitain de Paris
              </p>
            </div>
          </div>

          {/* ---- display map ---- */}
          <div className="mapPageBox">
            <div className="mapPage">
              <p>Cliquez</p>
              <h1 onClick={handleStart}>VISUALISER LA MAP</h1>
            </div>
          </div>
        </div>
      </div>
  );
}
