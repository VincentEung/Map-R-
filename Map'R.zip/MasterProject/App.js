// App.js
import React, { useEffect, useState } from "react";
import { View } from "react-native";
import HomePage from "./HomePage";
import Map from "./Map";
import Info from "./Info";
import GraphPage from "./GraphPage";
import PredictionsPage from "./PredictionsPage";
import locationsData from "./data/locations.json";

const App = () => {
  const [locations, setLocations] = useState([]);
  const [showHp, setShowHp] = useState(true);
  const [showMap, setShowMap] = useState(false);
  const [showInfo, setShowInfo] = useState(false);
  const [showGraph, setShowGraph] = useState(false);
  const [showPredictions, setShowPredictions] = useState(false);

  useEffect(() => {
    const filteredLocations = locationsData.filter(
      (location) => location.mode === "METRO"
    );
    setLocations(filteredLocations);
  }, []);

  const handleHp = () => {
    setShowHp(true);
    setShowMap(false);
    setShowInfo(false);
    setShowGraph(false);
    setShowPredictions(false);
  };

  const handleStart = () => {
    setShowMap(true);
    setShowHp(false);
    setShowInfo(false);
    setShowGraph(false);
    setShowPredictions(false);
  };

  const handleNoMap = () => {
    setShowMap(false);
    setShowHp(true);
  };

  const handleInfo = () => {
    setShowInfo(true);
    setShowHp(false);
    setShowMap(false);
    setShowGraph(false);
    setShowPredictions(false);
  };

  const handleNoInfo = () => {
    setShowInfo(false);
    setShowHp(true);
  };

  const handleGraphe = () => {
    setShowGraph(true);
    setShowHp(false);
    setShowMap(false);
    setShowInfo(false);
    setShowPredictions(false);
  };

  const handleNoGraphe = () => {
    setShowGraph(false);
    setShowHp(true);
  };

  const handlePredictions = () => {
    setShowPredictions(true);
    setShowHp(false);
    setShowMap(false);
    setShowInfo(false);
    setShowGraph(false);
  };

  const handleNoPredictions = () => {
    setShowPredictions(false);
    setShowHp(true);
  };

  return (
    <View style={{ flex: 1 }}>
      {/* Ajoutez la condition pour afficher la page de prédictions */}
      {showPredictions ? (
        <PredictionsPage
          handleNoPredictions={handleNoPredictions}
          homePageClick={handleHp}
          onStart={handleStart}
          infoClick={handleInfo}
          handleNoMap={handleNoMap}
          handleNoInfo={handleNoInfo}
        />
      ) : showGraph ? (
        <GraphPage
          handleNoGraph={handleNoGraphe}
          homePageClick={handleHp}
          onStart={handleStart}
          infoClick={handleInfo}
          handleNoMap={handleNoMap}
          handleNoInfo={handleNoInfo}
        />
      ) : showMap ? (
        <Map
          locations={locations}
          handleNoMap={handleNoMap}
          homePageClick={handleHp}
          onStart={handleStart}
          infoClick={handleInfo}
          handleNoInfo={handleNoInfo}
        />
      ) : showHp ? (
        <HomePage
          homePageClick={handleHp}
          onStart={handleStart}
          infoClick={handleInfo}
          handleNoMap={handleNoMap}
          handleGraph={handleGraphe}
          handlePredictions={handlePredictions} // Pass handlePredictions as a prop
        />
      ) : showInfo ? (
        <Info
          homePageClick={handleHp}
          onStart={handleStart}
          infoClick={handleInfo}
          handleNoMap={handleNoMap}
          handleNoInfo={handleNoInfo}
        />
      ) : (
        <HomePage
          homePageClick={handleHp}
          onStart={handleStart}
          infoClick={handleInfo}
          handleNoMap={handleNoMap}
          handleGraph={handleGraphe}
          handlePredictions={handlePredictions} // Pass handlePredictions as a prop
        />
      )}
    </View>
  );
};

export default App;
