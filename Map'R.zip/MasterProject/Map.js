import React, { useState } from "react";
import GoogleMapReact from "google-map-react";
import "./Map.css";
import { View, Text, StyleSheet } from "react-native";


const Map = ({ locations, handleHp, onStart, infoClick, handleNoMap, handleGraph }) => {
  const [isBoxOpen, setIsBoxOpen] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");

  
  const MapLegend = () => {
    return (
      <View style={styles.legendContainer}>
        <View style={[styles.legendItem, { backgroundColor: "grey" }]} />
        <Text style={styles.legendText}>Non disponible</Text>
  
        <View style={[styles.legendItem, { backgroundColor: "#50F0E6" }]} />
        <Text style={styles.legendText}>0-10</Text>
  
        <View style={[styles.legendItem, { backgroundColor: "#50CCAA" }]} />
        <Text style={styles.legendText}>11-20</Text>
  
        <View style={[styles.legendItem, { backgroundColor: "#EDE662" }]} />
        <Text style={styles.legendText}>21-25</Text>
  
        <View style={[styles.legendItem, { backgroundColor: "#ED5E58" }]} />
        <Text style={styles.legendText}>26-50</Text>
  
        <View style={[styles.legendItem, { backgroundColor: "#881A33" }]} />
        <Text style={styles.legendText}>51-75</Text>
  
        <View style={[styles.legendItem, { backgroundColor: "#73287D" }]} />
        <Text style={styles.legendText}>76+</Text>
      </View>
    );
  };

  const handleMapClick = () => {
    setIsBoxOpen(null);
  };

  const handleSearchChange = (event) => {
    const { value } = event.target;
    setSearchQuery(value);
  };

  const filteredLocations = locations.filter((location) =>
    location.nom_gares.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const styles = StyleSheet.create({
    legendContainer: {
      position: "absolute",
      top: 60,
      right: 20,
      backgroundColor: "white",
      padding: 10,
      borderRadius: 5,
      elevation: 5, // Shadow for Android
      shadowColor: "#000", // Shadow for iOS
      shadowOffset: {
        width: 0,
        height: 2,
      },
      shadowOpacity: 0.25,
      shadowRadius: 3.84,
    },
    legendItem: {
      width: 20,
      height: 20,
      borderRadius: 10,
      marginRight: 5,
    },
    legendText: {
      marginLeft: 5,
    },
  });  

  const handleNavigateToNewPage = () => {
    handleGraph();  // Appeler la fonction handleGraph lors du clic sur le bouton
  };

  const handleNavigateToPredictions = () => {
    handlePredictions();  // Assurez-vous que 'PredictionsPage' est le nom correct de votre écran de prédictions
  };

  return (
    <div className="map-container">
      {/* ----navigation bar---- */}
      <nav className="navbar">
        <a href="HomePage.js" className="hp">MAP'R</a>
        <div className="bars">
          <div className="barinfo" onClick={handleNoMap}>Accueil</div>
          <div className="barinfo" onClick={onStart}>Visualiser la carte</div>
          <div className="barinfo" onClick={handleNavigateToNewPage}> Graphiques </div>
          <div className="barinfo" onClick={handleNavigateToPredictions}> Prédictions </div>
          <div className="barinfo" onClick={infoClick}>Plus d'informations</div>
        </div>
      </nav>

      <div className="back-button">
        <button onClick={handleNoMap}>
          <svg
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 24 24"
            fill="black"
            width="18px"
            height="18px"
            style={{ transform: "rotate(360deg)" }}
          >
            <path d="M0 0h24v24H0z" fill="none" />
            <path d="M14.41 7.41L13 6l-6 6 6 6 1.41-1.41L9.83 12l4.58-4.59z" />
          </svg>
        </button>
      </div>

      <div className="search-bar">
        <input
          type="text"
          placeholder="Search..."
          value={searchQuery}
          onChange={handleSearchChange}
          className="search-input"
        />
      </div>

      <GoogleMapReact
        bootstrapURLKeys={{ key: "AIzaSyCYTOTpQZ4k9JEVsPZuoyOd3z5mSrZmOWg" }}
        defaultCenter={{ lat: 48.8566, lng: 2.3522 }}
        defaultZoom={10}
        onClick={handleMapClick}
      >
        {filteredLocations.map((location) => (
          <Marker
            key={location.id_gares}
            lat={location.geo_point_2d.lat}
            lng={location.geo_point_2d.lon}
            text={location.nom_gares}
            PM2_5={location.MoyennesPM2_5}
            PM10={location.MoyennesPM10}
            humidity={location.humidity} // Ajoutez la propriété d'humidité
            temperature={location.temperature} // Ajoutez la propriété de température
            isBoxOpen={isBoxOpen}
            setIsBoxOpen={setIsBoxOpen}
          />
        ))}
      </GoogleMapReact>

      {/* Legend */}
      <MapLegend />
    </div>
  );
};

const Marker = ({ text, PM2_5, PM10, humidity,temperature,isBoxOpen, setIsBoxOpen }) => {
  const [isClicked, setIsClicked] = useState(false);

  const handleClick = () => {
    setIsClicked(!isClicked);
    setIsBoxOpen(text);
  };

  const handleMapClick = () => {
    if (isClicked) {
      setIsClicked(false);
      setIsBoxOpen(null);
    }
  };

  let markerColor;
  if (PM2_5 === -1) {
    markerColor = "grey";
  } else if (PM2_5 >= 0 && PM2_5 < 11) {
    markerColor = "#50F0E6";
  } else if (PM2_5 >= 11 && PM2_5 < 21) {
    markerColor = "#50CCAA";
  } else if (PM2_5 >= 21 && PM2_5 < 26) {
    markerColor = "#EDE662";
  } else if (PM2_5 >= 26 && PM2_5 < 51) {
    markerColor = "#ED5E58";
  } else if (PM2_5 >= 51 && PM2_5 < 76) {
    markerColor = "#881A33";
  } else if (PM2_5 >= 76) {
    markerColor = "#73287D";
  }

  return (
    <div
      className={`marker${isClicked ? " marker-clicked" : ""}`}
      style={{ backgroundColor: markerColor }}
      onClick={handleClick}
    >
      <div className="marker-label">{PM2_5.toFixed(0)}</div>

      {isClicked && (isBoxOpen === text || isBoxOpen === PM2_5 || isBoxOpen === PM10) && (
        <div className="marker-info">
          <div>{text}</div>
          <div>PM2.5: {PM2_5.toFixed(2)}</div>
          <div>PM10: {PM10.toFixed(2)}</div>
          <div>Humidité: </div>
          <div>Temperature: </div>
        </div>
      )}
    </div>
  );
};



export default Map;
