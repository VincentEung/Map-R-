import React, { useState } from "react";
import "./PredictionsPage.css";

const PredictionsPage = ({ handleHp, onStart, infoClick, handleGraph, handlePredictions }) => {

  const handleNavigateToNewPage = () => {
    handleGraph();  // Appeler la fonction handleGraph lors du clic sur le bouton
  };

  const handleNavigateToPredictions = () => {
    handlePredictions();  // Appeler la fonction handleGraph lors du clic sur le bouton
  };

  return (
    <div className="main">
      {/*----navigation bar----*/}
      <nav className="navbar">
        <a href="HomePage.js" className="hp">MAP'R</a>
        <div className="bars">
          <div className="barinfo" onClick={handleHp}> Accueil</div>
          <div className="barinfo" onClick={onStart}> Visualiser la carte </div>
          <div className="barinfo" onClick={handleNavigateToNewPage}> Graphiques </div>
          <div className="barinfo" onClick={handleNavigateToPredictions}> Prédictions </div>
          <div className="barinfo" onClick={infoClick}> Plus d'informations </div>
        </div>
      </nav>
    </div>




  );
};

export default PredictionsPage;
