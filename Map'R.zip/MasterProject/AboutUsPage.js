import React from "react";
import "./AboutUsPage.css"
import "./Navbar.css";
import logo from "./images/logo1.png";

const AboutUsPage = ({ onAboutUsClick, onOurProjectClick,onReturnToHome,onVoirLaCarteClick }) => {
  return (
    <div>

<div className="navbar">
        
        <img src={logo}alt="Logo" className="logo" />
          <button className="nav-button">Accueil</button>
          <button className="nav-button" onClick={onOurProjectClick}>
            Notre projet
          </button> 
          
          <button className="nav-button" onClick={onVoirLaCarteClick}>
            Voir la Carte
          </button> 
          <button className="nav-button" onClick={onAboutUsClick}>
            About Us
          </button>
        </div>
        <div className="content">
      <h1>About Us</h1>
      <p>Here you can provide information about your team or organization.</p>
      </div>
      <button className="return-button" onClick={onReturnToHome}>
        Retour
      </button>
    </div>
  );
};

export default AboutUsPage;