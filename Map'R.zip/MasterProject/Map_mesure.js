import React, { useState, useEffect } from "react";
import GoogleMapReact from "google-map-react";
import axios from "axios";

const Map = ({ locations }) => {
  const [isBoxOpen, setIsBoxOpen] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [pmData, setPmData] = useState([]);

  useEffect(() => {
    // Fetch PM2.5 and PM10 data from CSV file
    const fetchPmData = async () => {
      try {
        const response = await axios.get("1eresMesures.csv");
        const csvData = response.data;

        // Parse CSV data
        const parsedData = parseCsvData(csvData);

        // Update PM data state
        setPmData(parsedData);
      } catch (error) {
        console.error("Error fetching PM data:", error);
      }
    };

    fetchPmData();
  }, []);

  const parseCsvData = (csvData) => {
    // Parse the CSV data into an array of objects
    const rows = csvData.split("\n");
    const headers = rows[0].split(";");
    const parsedData = [];

    for (let i = 1; i < rows.length; i++) {
      const row = rows[i].split(";");
      if (row.length === headers.length) {
        const rowData = {};
        for (let j = 0; j < headers.length; j++) {
          rowData[headers[j]] = row[j];
        }
        parsedData.push(rowData);
      }
    }

    return parsedData;
  };

  const handleMapClick = () => {
    setIsBoxOpen(null);
  };

  const handleSearchChange = (event) => {
    const { value } = event.target;
    setSearchQuery(value);
  };

  const filteredLocations = locations.filter((location) =>
    location.nom_gares.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getLocationPmData = (station, metro) => {
    const pmDataItem = pmData.find(
      (item) => item.station === station && item.metro === metro
    );
    return pmDataItem ? pmDataItem : null;
  };

  return (
    <div style={{ height: "100vh", width: "100%", position: "relative" }}>
      <div
        style={{
          position: "absolute",
          top: "0",
          left: "50%",
          transform: "translateX(-50%)",
          zIndex: "1",
        }}
      >
        <input
          type="text"
          placeholder="Search..."
          value={searchQuery}
          onChange={handleSearchChange}
          style={{ marginBottom: "10px" }}
        />
      </div>

      <GoogleMapReact
        bootstrapURLKeys={{
          key: "AIzaSyCYTOTpQZ4k9JEVsPZuoyOd3z5mSrZmOWg",
        }}
        defaultCenter={{ lat: 48.8566, lng: 2.3522 }}
        defaultZoom={10}
        onClick={handleMapClick}
      >
        {filteredLocations.map((location) => {
          const { nom_gares, indice_lig } = location;
          const pmDataItem = getLocationPmData(nom_gares, indice_lig);

          const pm2_5 = pmDataItem ? parseFloat(pmDataItem["MoyennesPM2.5"]) : location.PM2_5;
          const pm10 = pmDataItem ? parseFloat(pmDataItem["MoyennesPM10"]) : location.PM10;

          return (
            <Marker
              key={location.id_gares}
              lat={location.geo_point_2d.lat}
              lng={location.geo_point_2d.lon}
              text={nom_gares}
              ligne={indice_lig}
              PM2_5={pm2_5}
              PM10={pm10}
              isBoxOpen={isBoxOpen}
              setIsBoxOpen={setIsBoxOpen}
            />
          );
        })}
      </GoogleMapReact>
    </div>
  );
};

const Marker = ({
  text,
  ligne,
  PM2_5,
  PM10,
  isBoxOpen,
  setIsBoxOpen,
}) => {
  const [isClicked, setIsClicked] = useState(false);

  const handleClick = () => {
    setIsClicked(!isClicked);
    setIsBoxOpen(text);
  };

  const handleMapClick = () => {
    if (isClicked) {
      setIsClicked(false);
      setIsBoxOpen(null);
    }
  };

  const getMarkerColor = (pm2_5) => {
    const markerColor = `hsl(${120 - (pm2_5 / 50) * 120}, 100%, 50%)`;
    return markerColor;
  };

  return (
    <div
      style={{
        position: "relative",
        transform: "translate(-50%, -50%)",
        width: "20px",
        height: "20px",
        borderRadius: "50%",
        backgroundColor: getMarkerColor(PM2_5),
        textAlign: "center",
        color: "white",
        fontSize: "12px",
        fontWeight: "bold",
        cursor: "pointer",
        zIndex: isClicked ? 1 : "auto",
      }}
      onClick={handleClick}
    >
      <div style={{ position: "absolute", top: "50%", left: "50%", transform: "translate(-50%, -50%)" }}>
        {PM2_5.toFixed(0)}
      </div>

      {isClicked && (isBoxOpen === text || isBoxOpen === PM2_5 || isBoxOpen === PM10) && (
        <div
          style={{
            position: "absolute",
            top: "-60px",
            left: "50%",
            transform: "translateX(-50%)",
            padding: "5px",
            backgroundColor: "white",
            boxShadow: "0 2px 6px rgba(0, 0, 0, 0.3)",
            textAlign: "center",
            fontSize: "12px",
            fontWeight: "bold",
            width: "100px",
            color: "black",
            zIndex: 2,
          }}
          onClick={(e) => {
            e.stopPropagation();
          }}
        >
          <div>{text}</div>
          <div>PM2.5: {PM2_5.toFixed(2)}</div>
          <div>PM10: {PM10.toFixed(2)}</div>
        </div>
      )}
    </div>
  );
};

export default Map;
