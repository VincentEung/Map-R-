import React, { useState } from "react";
import { View, Text, TouchableOpacity, StyleSheet, Image } from 'react-native';

const GraphPage = ({ handleHp, onStart, infoClick, handleGraphe }) => {
  const [selectedLine, setSelectedLine] = useState(null);

  const handleLineSelect = (line) => {
    setSelectedLine(line);
    // Ajoutez ici la logique pour charger les données de la ligne sélectionnée.
  };
  const handleNavigateToNewPage = () => {
    handleGraphe();  // Appeler la fonction handleGraph lors du clic sur le bouton
  };
  const metroLines = ["L1", "L2", "L3","L3Bis", "L4", "L5", "L6", "L7","L7Bis", "L8", "L9", "L10", "L11", "L12", "L13", "L14"];
  
  const handleNavigateToPredictions = () => {
    // Naviguer vers la page de prédictions
    handlePrediction();  // Assurez-vous que 'PredictionsPage' est le nom correct de votre écran de prédictions
  };

  return (
    <View style={styles.container}>
      {/* Navigation Bar */}
      <View style={styles.navbar}>
        <TouchableOpacity onPress={handleHp} style={styles.hp}>
          <Text style={{ color: 'white', fontSize: 25 }}>MAP'R</Text>
        </TouchableOpacity>
        <View style={styles.bars}>
          <TouchableOpacity onPress={handleHp} style={styles.barinfo}>
            <Text>Accueil</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={onStart} style={styles.barinfo}>
            <Text>Visualiser la carte</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={handleNavigateToNewPage} style={styles.barinfo}>
            <Text>Graphiques</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={handleNavigateToPredictions} style={styles.barinfo}>
            <Text>Prediction</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={infoClick} style={styles.barinfo}>
            <Text>Plus d'informations</Text>
          </TouchableOpacity>
        </View>
      </View>

      <View style={styles.lineSelection}>
        <Text style={styles.lineSelectionText}>Choisissez une ligne de métro :</Text>
        <View style={styles.metroButtons}>
          {metroLines.map((line) => (
            <TouchableOpacity
              key={line}
              onPress={() => handleLineSelect(line)}
              style={[
                styles.metroButton,
                selectedLine === line && styles.selectedMetroButton,
                // Ajoutez un style spécifique pour chaque ligne ici
                line === "L1" && { backgroundColor: '#f2d602' },
                line === "L2" && { backgroundColor: '#0276fa' },
                line === "L3" && { backgroundColor: '#678a68' },
                line === "L3Bis" && { backgroundColor: '#90e5f0' },
                line === "L4" && { backgroundColor: '#ed49f2' },
                line === "L5" && { backgroundColor: '#ff922b' },
                line === "L6" && { backgroundColor: '#87f5af' },
                line === "L7" && { backgroundColor: '#ecb5f7' },
                line === "L7Bis" && { backgroundColor: '#97c791' }, 
                line === "L8" && { backgroundColor: '#db8ef5' }, 
                line === "L9" && { backgroundColor: '#c4f05d' }, 
                line === "L10" && { backgroundColor: '#edcd2b' }, 
                line === "L11" && { backgroundColor: '#ab6503' }, 
                line === "L12" && { backgroundColor: '#299608' }, 
                line === "L13" && { backgroundColor: '#60dbdb' }, 
                line === "L14" && { backgroundColor: '#8d2c94' }, 
              ]}
            >
              <Text style={styles.metroButtonText}>{line}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      {/* Image 8 */}
      <View style={styles.imageContainer}>
        {selectedLine && selectedLine === "L8" && (
          <Image
            source={require(`./images/L8_base.png`)}
            style={[styles.image, { borderWidth: 1, borderColor: 'gray', borderRadius: 8, shadowColor: '#000', shadowOffset: { width: 0, height: 3 }, shadowOpacity: 0.3, shadowRadius: 4, marginRight:10 }]}
            />
        )}

        {selectedLine && selectedLine === "L10" && (
          <Image
            source={require(`./images/L10_base.png`)}
            style={[styles.image, { borderWidth: 1, borderColor: 'gray', borderRadius: 8, shadowColor: '#000', shadowOffset: { width: 0, height: 3 }, shadowOpacity: 0.3, shadowRadius: 4, marginRight:10 }]}
            />
        )}

        {selectedLine && selectedLine === "L14" && (
          <View style={styles.imageWithTextContainer}>
            <View style={styles.columnContainer}>
              <Image
                source={require(`./images/14-1.jpg`)}
                style={[styles.image, { borderWidth: 1, borderColor: 'gray', borderRadius: 8, shadowColor: '#000', shadowOffset: { width: 0, height: 3 }, shadowOpacity: 0.3, shadowRadius: 4, marginRight:10 }]}
                />
              <Image
                source={require(`./images/14-6.jpg`)}
                style={[styles.image, { borderWidth: 1, borderColor: 'gray', borderRadius: 8, shadowColor: '#000', shadowOffset: { width: 0, height: 3 }, shadowOpacity: 0.3, shadowRadius: 4 , marginHorizontal: 10}]}
                />
              <Image
                source={require(`./images/14-5.jpg`)}
                style={[styles.image, { borderWidth: 1, borderColor: 'gray', borderRadius: 8, shadowColor: '#000', shadowOffset: { width: 0, height: 3 }, shadowOpacity: 0.3, shadowRadius: 4, marginLeft:10 }]}
                />
            </View>
            <View style={styles.columnContainer}>
              <Image
                source={require(`./images/14-4.jpg`)}
                style={[styles.image, { borderWidth: 1, borderColor: 'gray', borderRadius: 8, shadowColor: '#000', shadowOffset: { width: 0, height: 3 }, shadowOpacity: 0.3, shadowRadius: 4, marginRight:10 }]}
                />
              <Image
                source={require(`./images/14-3.jpg`)}
                style={[styles.image, { borderWidth: 1, borderColor: 'gray', borderRadius: 8, shadowColor: '#000', shadowOffset: { width: 0, height: 3 }, shadowOpacity: 0.3, shadowRadius: 4, marginHorizontal: 10 }]}
                />
              <Image
                source={require(`./images/14-2.jpg`)}
                style={[styles.image, { borderWidth: 1, borderColor: 'gray', borderRadius: 8, shadowColor: '#000', shadowOffset: { width: 0, height: 3 }, shadowOpacity: 0.3, shadowRadius: 4, marginLeft:10 }]}
                />
            </View>
            <Text style={styles.graphTitle}>Explication pour le graphique 1</Text>
          </View>
        )}
      </View>
    </View>
  );
};
const styles = StyleSheet.create({
  container: {
    flex: 1,
  },

  navbar: {
    flexDirection: 'row',
    backgroundColor: '#a3e571',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 10,
  },

  hp: {
    fontSize: 25,
    color: 'white',
  },

  bars: {
    flexDirection: 'row',
  },

  barinfo: {
    marginHorizontal: 10,
    fontSize: 16,
  },  

  lineSelection: {
    alignItems: 'center',
    marginVertical: 10,
  },

  lineSelectionText: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
  },

  metroButtons: {
    flexDirection: 'row',
    justifyContent: 'center',
  },

  metroButton: {
    backgroundColor: '#a3e571',
    padding: 10,
    marginHorizontal: 5,
    borderRadius: 8,
  },

  selectedMetroButton: {
    backgroundColor: '#50CCAA',
  },

  graphTitle: {
    textAlign: 'center',
    fontSize: 18,
    fontWeight: 'bold',
    marginTop: 10,
  },

  imageText: {
    textAlign: 'center',
    fontSize: 16,
    color: 'gray',
  },
  metroButtonText: {
    fontSize: 16,
    color: 'white',
  },

  imageContainer: {
    alignItems: 'center',
    marginVertical: 10,
    flexDirection: 'column', // Changez la direction du flux pour afficher en colonnes
    alignItems: 'center',
  },

  columnContainer: {
    flexDirection: 'row', // Mettez en place une direction de flux en ligne pour les colonnes
    justifyContent: 'space-between', // Espacez uniformément les éléments dans la ligne
    marginBottom: 10, // Ajoutez une marge entre les colonnes
  },

  image: {
    width: 600,  // Remplacez par la largeur réelle de votre image
    height: 400, // Remplacez par la hauteur réelle de votre image
    marginVertical: 10,
    borderWidth: 2, // Ajustez l'épaisseur de la bordure selon vos préférences
    borderColor: 'gray', // Couleur de la bordure
    borderRadius: 8, // Si vous souhaitez ajouter des coins arrondis
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
  },
});

export default GraphPage;
